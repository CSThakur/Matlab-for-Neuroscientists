%Chp 22.
%Exercise 22.1.
%See Figure 22.1 for an example picture
%a)This produces Regular Spiking (RS)
%b)This produces Intrinsic Bursting (IB)
%c)This produces Fast Spiking (FS)
%d)This produces Resonance (RZ)

%Exercise 22.2
%The excitatory neurons will largely be regular spiking neurons, while the
%inhibitory neurons will be resonators and fast spikers predominantly.
