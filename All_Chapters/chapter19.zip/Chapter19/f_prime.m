function df=f_prime(x, param)

df=2*x;